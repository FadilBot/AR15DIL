const donasi = () => {
	return `𝗗𝗜𝗟𝗕𝗢𝗧

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 0857-2255-3839
┣➥ *PULSA:* 0857-2255-3839
┣➥ *OVO:* 0857-2255-3839
┃ 
┗━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
