const help = (prefix) => {
	return `𝗗𝗜𝗟𝗕𝗢𝗧
	
	                
┏━━━━━━━━━━━━━━━━━━━━
┃      *FITUR DILBOT*
┣━━━━━━━━━━━━━━━━━━━━
┣➥ *${prefix}owner*
┣➥ *${prefix}donasi*
┣➥ *${prefix}info*
┣➥ *${prefix}sticker*
┣➥ *${prefix}tsticker*
┣➥ *${prefix}nulis* [teks]
┣➥ *${prefix}tts*
┣➥ *${prefix}tiktok*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *yt* [linkyoutube]
┣➥ *${prefix}add* [62xxx]
┣➥ *${prefix}kick* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}clone* [tag]
┣➥ *${prefix}demote* [tag]
┣➥ *${prefix}promote* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}group* [buka/tutup]
┣➥ *${prefix}welcome* [1/0]
┣➥ *${prefix}nsfw* [1/0]
┣➥ *${prefix}simih* [1/0]
┣➥ *${prefix}bc* 
┣➥ *${prefix}leave*
┣➥ *${prefix}clearall*
┣➥ *${prefix}setprefik*
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}listadmin*
┣➥ *${prefix}blocklist*
┣➥ *${prefix}simi*
┣➥ *${prefix}wait*
┣➥ *${prefix}fitnah*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}url2img*
┣➥ *${prefix}textimage*
┣➥ *${prefix}shota*
┣➥ *${prefix}say*
┣➥ *${prefix}nekopoi*
┣➥ *${prefix}wetzodiak*
┣➥ *${prefix}igstalk*
┣➥ *${prefix}profileig* [link]
┣➥ *${prefix}loli2*
┣➥ *${prefix}bitly*
┣➥ *${prefix}animesearch*
┣➥ *${prefix}lirik* [nama lagu]
┣➥ *${prefix}fotoanime*
┣➥ *${prefix}foto cowok*
┣➥ *${prefix}foto cewek*
┣➥ *${prefix}fakta*
┣➥ *${prefix}pornhub* [text|text]
┣➥ *${prefix}hentai*
┣➥ *${prefix}gltext*
┣➥ *${prefix}indohot*
┣➥ *${prefix}neolast*
┣➥ *${prefix}bucin*
┣➥ *${prefix}pasangan*
┣➥ *${prefix}quotesanime*
┣➥ *${prefix}map*
┣➥ *${prefix}infogempa*
┣➥ *${prefix}mostviewfilm*
┣➥ *${prefix}filmanime*
┣➥ *${prefix}nulis2* [teks]
┣➥ *${prefix}randomhentai2*
┣➥ *${prefix}puisi1*
┣➥ *${prefix}randomkis*
┣➥ *${prefix}nekopoi2*
┣➥ *${prefix}ttp*
┣➥ *${prefix}otakudesu*
┣➥ *${prefix}cersex1*
┣➥ *${prefix}cersex2*
┣➥ *${prefix}tts2*
┣➥ *${prefix}texthunder*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}dewabatch*
┣➥ *${prefix}ttp2*
┣➥ *${prefix}quran*
┣➥ *${prefix}ping*
┣➥ *${prefix}ping2*
┣➥ *${prefix}speed*
┣➥ *${prefix}twt* [linkTweet]
┣➥ *${prefix}sholat* [daerah]
┣➥ *${prefix}covid*
┣➥ *${prefix}pokemon*
┣➥ *${prefix}spamsms*
┣➥ *${prefix}spamcall*
┣➥ *${prefix}wikien*
┣➥ *${prefix}urltoimg* [link]
┣➥ *${prefix}gaming2*
┣➥ *${prefix}gay*
┣➥ *${prefix}wiki* [query] Wikipedia.
┣➥ *${prefix}fb* [linkfb]
┣➥ *${prefix}ig* [linkig]
┣➥ *${prefix}ytmp3* [linkyoutube]
┣➥ *${prefix}ytmp4* [linkyoutube]
┣➥ *${prefix}ytmp5* [linkyoutube]
┣➥ *${prefix}ytmp6* [linkyoutube]
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┣━━━━━━━━━━━━━━━━━━━━
┃ *DONASI KE ARIS187  KETIK* 
┃ *!DONASI*
┣━━━━━━━━━━━━━━━━━━━━
┃ *POWERED BY FADIL & ARIS187*
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

